//
//  FourthVC.m
//  MMTapBar
//
//  Created by wyy on 16/11/29.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import "FourthVC.h"

@implementation FourthVC
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor yellowColor];
}
@end
