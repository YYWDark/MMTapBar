//
//  MMTabBarModel.m
//  MMTapBar
//
//  Created by wyy on 16/11/22.
//  Copyright © 2016年 yyx. All rights reserved.
//

#import "MMTabBarModel.h"

@implementation MMTabBarModel

@end
