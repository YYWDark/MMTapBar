//
//  MMHeader.h
//  MMPhotoView
//
//  Created by wyy on 16/11/10.
//  Copyright © 2016年 yyx. All rights reserved.
//

#ifndef MMHeader_h
#define MMHeader_h
#import "UIView+Extension.h"
#import "UIColor+Extension.h"

static const CGFloat titleFontSize = 14.0f;
static  CGFloat titleHorizontalMargin = 10.0f;       //左右的边距
static  CGFloat distanceBetweenTitles= 10.0f;        //title之间的距离
static  CGFloat titleScrollViewToTop = 0.0f;
static  CGFloat collectionViewToBottom = 0.0f;
#define kScreenHeigth [UIScreen mainScreen].bounds.size.height
#define kScreenWidth  [UIScreen mainScreen].bounds.size.width
#endif /* MMHeader_h */
